# IMaTFE — Stage 5: PSX texture rasterization

## Scope

This stage implements the first texture path of the PSX GPU model: 4-bit CLUT, 8-bit CLUT, 15-bit direct textures, texture-page addressing, UV coordinates, CLUT selection, texture-window addressing, and textured rectangles/triangles. It keeps the existing VRAM, drawing-area clipping, mask-bit path, and primitive rasterizer.

## Source basis

- `Hardware.pdf`, PlayStation Hardware, Chapter 3: the GPU has 1 MiB VRAM; texture pages are 256x256 logical texels stored in the framebuffer; the three texture modes are 4-bit CLUT, 8-bit CLUT, and 15-bit direct; CLUT entries are 15-bit pixels.
- `psx-spx.pdf`, section 2.3 GPU, especially pp. 117–125 and 148–155: GP0 polygon/rectangle packet layout, UV/CLUT/TPage fields, TPage color-mode bits, texture-window masking, texture addressing, transparent texture color 0000h, affine (non-perspective-correct) interpolation, and texture-cache organization.

## Implemented PSX-specific rules

- 4-bit mode: four texels per VRAM halfword; each texel is a 4-bit CLUT index.
- 8-bit mode: two texels per VRAM halfword; each texel is an 8-bit CLUT index.
- 15-bit mode: one texel per VRAM halfword.
- TPage X base is expressed in 64-halfword units; Y base selects the 256-line page bank.
- For 4/8-bit modes, the CLUT X coordinate is expressed in 16-halfword units and the CLUT Y coordinate is a VRAM line.
- Textured polygon packets carry the CLUT in the first UV word and TPage in the second UV word; subsequent UV words carry only U/V.
- Rectangle primitives use the current GP0(E1h) TPage and carry the CLUT in their UV word.
- UVs are interpolated linearly across polygons; there is deliberately no perspective correction.
- Texture window masking is applied to U/V before texture-page sampling.
- Texture color 0000h is treated as fully transparent and therefore does not overwrite the framebuffer.
- Raw and modulated texture modes are represented; modulation uses the PSX 8-bit color scale where 0x80 is the nominal maximum.

## Deliberately not in this stage

Semi-transparency blending, dithering, exact GPU texture-cache timing/conflict behavior, and the remaining rasterization quirks are kept for the following rasterization stages. The 2 MiB VRAM extension is not enabled by this implementation.

## Verification

Stage 5 contains tests for framebuffer access, existing primitive rasterization, 4-bit/8-bit/15-bit texture formats, CLUT lookup, texture-page addressing, textured polygon UV packets, transparent texels, texture-window addressing, and existing clipping.
